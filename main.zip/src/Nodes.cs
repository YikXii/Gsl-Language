using System.Collections.Generic;

abstract class Node {}

class NumberNode   : Node { public Token? Tok { get; set; } }
class StringNode   : Node { public Token? Tok { get; set; } }
class BoolNode     : Node { public bool Val { get; set; } }
class IdentNode    : Node { public string? Name { get; set; } }
class BinOpNode    : Node { public Node? Left { get; set; } public Node? Right { get; set; } public TType Op { get; set; } }
class UnOpNode     : Node { public TType Op { get; set; } public Node? Operand { get; set; } }
class CallNode     : Node { public string? Name { get; set; } public List<Node>? Args { get; set; } }
class IndexNode    : Node { public Node? Obj { get; set; } public Node? Idx { get; set; } }
class PackNode     : Node { public List<Node>? Items { get; set; } }
class MapNode      : Node { public List<(Node Key, Node Val)>? Pairs { get; set; } }
class CalcNode     : Node { public Node? Expr { get; set; } }
class AskNode      : Node { public Node? Prompt { get; set; } }
class SizeofNode   : Node { public Node? Expr { get; set; } }
class KindofNode   : Node { public Node? Expr { get; set; } }
class RandNode     : Node { public Node? Min { get; set; } public Node? Max { get; set; } }

class MakeStmt         : Node { public string? Name { get; set; } public Node? Value { get; set; } }
class AssignStmt       : Node { public string? Name { get; set; } public Node? Value { get; set; } }
class CompoundAssignStmt : Node { public string? Name { get; set; } public TType Op { get; set; } public Node? Value { get; set; } }
class IndexAssignStmt  : Node { public string? Name { get; set; } public Node? Idx { get; set; } public Node? Value { get; set; } }
class MapAssignStmt    : Node { public string? Name { get; set; } public Node? Key { get; set; } public Node? Value { get; set; } }
class SayStmt          : Node { public Node? Expr { get; set; } }
class GiveStmt         : Node { public Node? Expr { get; set; } }
class PauseStmt        : Node { public Node? Expr { get; set; } }
class PushinStmt       : Node { public string? Name { get; set; } public Node? Value { get; set; } }
class PulloutStmt      : Node { public string? Name { get; set; } public Node? Idx { get; set; } }
class CallStmt         : Node { public string? Name { get; set; } public List<Node>? Args { get; set; } }
class StopStmt         : Node {}
class SkipStmt         : Node {}

class CheckStmt : Node {
    public List<(Node Cond, List<Node> Body)>? Cases { get; set; }
    public List<Node>? Otherwise { get; set; }
}

class CycleStmt : Node {
    public Node? Count { get; set; }
    public List<Node>? Body { get; set; }
}

class SpinStmt : Node {
    public Node? Cond { get; set; }
    public List<Node>? Body { get; set; }
}

// foreach item in listExpr { ... }
class ForeachStmt : Node {
    public string? Var { get; set; }
    public Node? List { get; set; }
    public List<Node>? Body { get; set; }
}

class CraftStmt : Node {
    public string? Name { get; set; }
    public List<string>? Params { get; set; }
    public List<Node>? Body { get; set; }
}

class LinkStmt : Node {
    public string? Module { get; set; }
}

class BlockNode : Node {
    public List<Node>? Stmts { get; set; }
}
