namespace GSL;

using System;
using System.IO;
using System.Net;

class Program {
    static void Main(string[] args) {
        Interpreter interpreter = new Interpreter();

        // Check for commands (lcsp, pcsp) or script execution (gsp)
        if (args.Length > 0) {
            string cmd = args[0].ToLower();

            // gsp command - run GSL script
            if (cmd == "gsp") {
                if (args.Length < 2) {
                    Console.WriteLine("Usage: gsp <filename>.gsl");
                    return;
                }
                string filename = args[1];
                if (!filename.EndsWith(".gsl")) {
                    filename += ".gsl";
                }
                if (!File.Exists(filename)) {
                    Console.WriteLine($"File not found: {filename}");
                    return;
                }
                try {
                    string src = File.ReadAllText(filename);
                    var tokens = new Lexer(src).TokenizeAll();
                    var ast = new Parser(tokens).Parse();
                    interpreter.Run(ast);
                } catch (Exception ex) {
                    Console.WriteLine($"Error: {ex.Message}");
                }
                return;
            }

            // lcsp command - link custom plugin
            if (cmd == "lcsp") {
                if (args.Length < 2) {
                    Console.WriteLine("Usage: lcsp <pluginname> or lcsp <pluginfolder>");
                    return;
                }
                string pluginArg = args[1];
                string pluginPath = $"plugins/{pluginArg}";
                if (Directory.Exists(pluginPath)) {
                    string[] candidates = { "main.gsl", "init.gsl", "core.gsl" };
                    bool found = false;
                    foreach (var file in candidates) {
                        string tryPath = Path.Combine(pluginPath, file);
                        if (File.Exists(tryPath)) {
                            try {
                                string pluginSrc = File.ReadAllText(tryPath);
                                var pluginTokens = new Lexer(pluginSrc).TokenizeAll();
                                var pluginAst = new Parser(pluginTokens).Parse();
                                interpreter.Run(pluginAst);
                                Console.WriteLine($"Plugin '{pluginArg}/{file}' loaded.");
                                found = true;
                                break;
                            } catch (Exception ex) {
                                Console.WriteLine($"Error loading plugin: {ex.Message}");
                                found = true;
                                break;
                            }
                        }
                    }
                    if (!found) {
                        Console.WriteLine($"No main.gsl, init.gsl, or core.gsl found in {pluginPath}");
                    }
                    return;
                } else if (File.Exists(pluginPath + ".gsl")) {
                    pluginPath += ".gsl";
                }
                if (!File.Exists(pluginPath)) {
                    Console.WriteLine($"Plugin not found: {pluginPath}");
                    return;
                }
                try {
                    string pluginSrc = File.ReadAllText(pluginPath);
                    var pluginTokens = new Lexer(pluginSrc).TokenizeAll();
                    var pluginAst = new Parser(pluginTokens).Parse();
                    interpreter.Run(pluginAst);
                    Console.WriteLine($"Plugin '{pluginArg}' loaded.");
                } catch (Exception ex) {
                    Console.WriteLine($"Error loading plugin: {ex.Message}");
                }
                return;
            }

            // pcsp command - plugin custom source pull
            if (cmd == "pcsp") {
                if (args.Length < 2) {
                    Console.WriteLine("Usage: pcsp <url> [pluginname]");
                    return;
                }
                string url = args[1];
                string? pluginName = null;

                if (args.Length >= 3) {
                    pluginName = args[2];
                } else if (url.Contains(" ")) {
                    var urlParts = url.Split(' ', 2);
                    url = urlParts[0];
                    pluginName = urlParts[1].Trim();
                }

                if (pluginName == null) {
                    try {
                        pluginName = Path.GetFileNameWithoutExtension(new Uri(url).AbsolutePath);
                    } catch {
                        pluginName = "plugin" + DateTime.Now.Ticks;
                    }
                }

                // Handle Pastebin raw URLs
                if (url.Contains("pastebin.com/raw/") || url.EndsWith(".gsl")) {
                    string pluginPath = $"plugins/{pluginName}.gsl";
                    try {
                        using (var client = new WebClient()) {
                            client.DownloadFile(url, pluginPath);
                        }
                        Console.WriteLine($"Plugin downloaded to {pluginPath}");
                    } catch (Exception ex) {
                        Console.WriteLine($"Error downloading plugin: {ex.Message}");
                    }
                    return;
                }

                // Handle GitHub repo
                if (url.Contains("github.com") && !url.EndsWith(".zip")) {
                    if (url.EndsWith("/")) url = url.Substring(0, url.Length - 1);
                    string zipUrl = url + "/archive/refs/heads/main.zip";
                    url = zipUrl;
                }

                // Handle .zip file
                if (url.EndsWith(".zip")) {
                    string zipPath = $"plugins/{pluginName}.zip";
                    string extractPath = $"plugins/{pluginName}";
                    try {
                        using (var client = new WebClient()) {
                            client.DownloadFile(url, zipPath);
                        }
                        if (System.IO.Directory.Exists(extractPath))
                            System.IO.Directory.Delete(extractPath, true);
                        System.IO.Compression.ZipFile.ExtractToDirectory(zipPath, extractPath);
                        File.Delete(zipPath);
                        Console.WriteLine($"Plugin extracted to {extractPath}");
                        string readmePath = Path.Combine(extractPath, "README.md");
                        if (File.Exists(readmePath)) {
                            Console.WriteLine("--- README.md ---");
                            Console.WriteLine(File.ReadAllText(readmePath));
                            Console.WriteLine("-----------------");
                        }
                    } catch (Exception ex) {
                        Console.WriteLine($"Error downloading/extracting plugin: {ex.Message}");
                    }
                    return;
                }

                Console.WriteLine("Unknown plugin source type. Supported: Pastebin raw, .gsl, GitHub repo, .zip");
                return;
            }

            // Unknown command
            Console.WriteLine("Unknown command. Available commands:");
            Console.WriteLine("  gsp <filename>.gsl  - Run a GSL script");
            Console.WriteLine("  lcsp <pluginname>   - Load a custom plugin");
            Console.WriteLine("  pcsp <url> [name]   - Download and load a plugin from URL");
        } else {
            Console.WriteLine("GSL Interpreter");
            Console.WriteLine("Usage:");
            Console.WriteLine("  gsp <filename>.gsl  - Run a GSL script");
            Console.WriteLine("  lcsp <pluginname>   - Load a custom plugin");
            Console.WriteLine("  pcsp <url> [name]   - Download and load a plugin from URL");
        }
    }
}

