using System;
using System.Collections.Generic;

class Parser {
    readonly List<Token> _toks;
    int _pos;

    public Parser(List<Token> toks) { _toks = toks; }

    Token Cur           => _toks[_pos];
    Token Adv()         { var t = _toks[_pos]; if (_pos < _toks.Count-1) _pos++; return t; }
    bool  Check(TType t)=> Cur.Type == t;
    bool  Match(TType t){ if (Check(t)) { Adv(); return true; } return false; }
    Token Expect(TType t, string msg) { if (!Check(t)) Err(msg); return Adv(); }
    void  Err(string msg) => throw new Exception($"[Line {Cur.Line}] Parse error: {msg} (got {Cur.Type} '{Cur.Raw}')");

    public List<string> LinkedModules = new List<string>();

    public BlockNode Parse() {
        var stmts = new List<Node>();
        while (!Check(TType.EOF)) {
            if (Check(TType.LINK)) {
                var linkStmt = ParseLink();
                if (linkStmt is LinkStmt l && l.Module != null)
                    LinkedModules.Add(l.Module);
                stmts.Add(linkStmt);
            } else {
                stmts.Add(ParseStmt());
            }
        }
        return new BlockNode { Stmts = stmts };
    }

    Node ParseLink() {
        Adv(); // consume 'link'
        Expect(TType.STAR, "Expected '*' after 'link'");
        var mod = Expect(TType.IDENT, "Expected module name after 'link *'").Raw;
        return new LinkStmt { Module = mod };
    }

    List<Node> ParseBlock() {
        Expect(TType.LBRACE, "Expected '{'");
        var stmts = new List<Node>();
        while (!Check(TType.RBRACE) && !Check(TType.EOF)) stmts.Add(ParseStmt());
        Expect(TType.RBRACE, "Expected '}'");
        return stmts;
    }

    Node ParseStmt() {
        switch (Cur.Type) {
            case TType.LINK:    return ParseLink();
            case TType.MAKE:    return ParseMake();
            case TType.SAY:     return ParseSay();
            case TType.CHECK:   return ParseCheck();
            case TType.CYCLE:   return ParseCycle();
            case TType.SPIN:    return ParseSpin();
            case TType.FOREACH: return ParseForeach();
            case TType.CRAFT:   return ParseCraft();
            case TType.GLOBAL:  return ParseGlobalCraft();
            case TType.GIVE:    return ParseGive();
            case TType.PUSHIN:  return ParsePushin();
            case TType.PULLOUT: return ParsePullout();
            case TType.PAUSE:   return ParsePause();
            case TType.STOP:    Adv(); return new StopStmt();
            case TType.SKIP:    Adv(); return new SkipStmt();
            case TType.IDENT:   return ParseAssignOrCall();
            default: throw new Exception($"Unexpected token '{Cur.Raw}'");
        }
    }

    Node ParseGlobalCraft() {
        Adv(); // consume 'global'
        return ParseCraft();
    }

    Node ParseMake() {
        Adv();
        string name = Expect(TType.IDENT, "Expected variable name").Raw;
        Expect(TType.EQ, "Expected '='");
        return new MakeStmt { Name = name, Value = ParseExpr() };
    }

    Node ParseSay() {
        Adv();
        return new SayStmt { Expr = ParseExpr() };
    }

    Node ParseCheck() {
        Adv();
        var cases = new List<(Node, List<Node>)>();
        cases.Add((ParseExpr(), ParseBlock()));

        while (Check(TType.BRANCH)) {
            Adv();
            cases.Add((ParseExpr(), ParseBlock()));
        }

        List<Node>? otherwise = null;
        if (Check(TType.OTHERWISE)) { Adv(); otherwise = ParseBlock(); }

        return new CheckStmt { Cases = cases, Otherwise = otherwise };
    }

    Node ParseCycle() {
        Adv();
        return new CycleStmt { Count = ParseExpr(), Body = ParseBlock() };
    }

    Node ParseSpin() {
        Adv();
        return new SpinStmt { Cond = ParseExpr(), Body = ParseBlock() };
    }

    // foreach item in listExpr { ... }
    Node ParseForeach() {
        Adv(); // consume 'foreach'
        string varName = Expect(TType.IDENT, "Expected variable name after 'foreach'").Raw;
        Expect(TType.IN, "Expected 'in' after foreach variable");
        var listExpr = ParseExpr();
        var body = ParseBlock();
        return new ForeachStmt { Var = varName, List = listExpr, Body = body };
    }

    Node ParseCraft() {
        Adv();
        string name = Expect(TType.IDENT, "Expected function name").Raw;
        Expect(TType.LPAREN, "Expected '('");
        var parms = new List<string>();
        while (!Check(TType.RPAREN) && !Check(TType.EOF)) {
            parms.Add(Expect(TType.IDENT, "Expected parameter name").Raw);
            Match(TType.COMMA);
        }
        Expect(TType.RPAREN, "Expected ')'");
        return new CraftStmt { Name = name, Params = parms, Body = ParseBlock() };
    }

    Node ParseGive() {
        Adv();
        return new GiveStmt { Expr = ParseExpr() };
    }

    Node ParsePushin() {
        Adv();
        string name = Expect(TType.IDENT, "Expected list name").Raw;
        return new PushinStmt { Name = name, Value = ParseExpr() };
    }

    Node ParsePullout() {
        Adv();
        string name = Expect(TType.IDENT, "Expected list name").Raw;
        return new PulloutStmt { Name = name, Idx = ParseExpr() };
    }

    Node ParsePause() {
        Adv();
        return new PauseStmt { Expr = ParseExpr() };
    }

    Node ParseAssignOrCall() {
        string name = Adv().Raw;

        // Function call statement
        if (Check(TType.LPAREN))
            return new CallStmt { Name = name, Args = ParseArgList() };

        // Compound assignment: x += expr, x -= expr, x *= expr, x /= expr
        if (Cur.Type is TType.PLUSEQ or TType.MINUSEQ or TType.STAREQ or TType.SLASHEQ) {
            var op = Adv().Type;
            return new CompoundAssignStmt { Name = name, Op = op, Value = ParseExpr() };
        }

        // Index assignment: x[idx] = expr  OR  x[key] = expr (map)
        if (Check(TType.LBRACKET)) {
            Adv();
            var idx = ParseExpr();
            Expect(TType.RBRACKET, "Expected ']'");
            Expect(TType.EQ, "Expected '='");
            // If the key is a string literal, emit MapAssignStmt so interpreter can handle maps too
            return new IndexAssignStmt { Name = name, Idx = idx, Value = ParseExpr() };
        }

        // Plain assignment
        Expect(TType.EQ, "Expected '='");
        return new AssignStmt { Name = name, Value = ParseExpr() };
    }

    List<Node> ParseArgList() {
        Expect(TType.LPAREN, "Expected '('");
        var args = new List<Node>();
        while (!Check(TType.RPAREN) && !Check(TType.EOF)) {
            args.Add(ParseExpr());
            Match(TType.COMMA);
        }
        Expect(TType.RPAREN, "Expected ')'");
        return args;
    }

    Node ParseExpr()    => ParseOr();

    Node ParseOr() {
        var left = ParseAnd();
        while (Check(TType.OR)) { var op = Adv().Type; left = new BinOpNode { Left=left, Op=op, Right=ParseAnd() }; }
        return left;
    }

    Node ParseAnd() {
        var left = ParseNot();
        while (Check(TType.AND)) { var op = Adv().Type; left = new BinOpNode { Left=left, Op=op, Right=ParseNot() }; }
        return left;
    }

    Node ParseNot() {
        if (Check(TType.NOT)) { var op = Adv().Type; return new UnOpNode { Op=op, Operand=ParseNot() }; }
        return ParseCompare();
    }

    Node ParseCompare() {
        var left = ParseAdd();
        while (Cur.Type is TType.EQEQ or TType.NEQ or TType.LT or TType.GT or TType.LTE or TType.GTE) {
            var op = Adv().Type;
            left = new BinOpNode { Left=left, Op=op, Right=ParseAdd() };
        }
        return left;
    }

    Node ParseAdd() {
        var left = ParseMul();
        while (Cur.Type is TType.PLUS or TType.MINUS) {
            var op = Adv().Type;
            left = new BinOpNode { Left=left, Op=op, Right=ParseMul() };
        }
        return left;
    }

    Node ParseMul() {
        var left = ParseUnary();
        while (Cur.Type is TType.STAR or TType.SLASH or TType.PERCENT) {
            var op = Adv().Type;
            left = new BinOpNode { Left=left, Op=op, Right=ParseUnary() };
        }
        return left;
    }

    Node ParseUnary() {
        if (Check(TType.MINUS)) { var op = Adv().Type; return new UnOpNode { Op=op, Operand=ParseUnary() }; }
        return ParsePostfix();
    }

    Node ParsePostfix() {
        var node = ParsePrimary();
        while (Check(TType.LBRACKET)) {
            Adv();
            var idx = ParseExpr();
            Expect(TType.RBRACKET, "Expected ']'");
            node = new IndexNode { Obj=node, Idx=idx };
        }
        return node;
    }

    Node ParsePrimary() {
        var t = Cur;

        if (t.Type == TType.INT)    { Adv(); return new NumberNode { Tok=t }; }
        if (t.Type == TType.FLOAT)  { Adv(); return new NumberNode { Tok=t }; }
        if (t.Type == TType.STRING) { Adv(); return new StringNode { Tok=t }; }

        // Boolean literals
        if (t.Type == TType.TRUE)   { Adv(); return new BoolNode { Val=true }; }
        if (t.Type == TType.FALSE)  { Adv(); return new BoolNode { Val=false }; }

        if (t.Type == TType.LPAREN) {
            Adv(); var v = ParseExpr(); Expect(TType.RPAREN, "Expected ')'"); return v;
        }

        if (t.Type == TType.ASK)    { Adv(); return new AskNode    { Prompt = ParseExpr() }; }
        if (t.Type == TType.CALC)   { Adv(); return new CalcNode   { Expr   = ParseExpr() }; }
        if (t.Type == TType.SIZEOF) { Adv(); return new SizeofNode { Expr   = ParseExpr() }; }
        if (t.Type == TType.KINDOF) { Adv(); return new KindofNode { Expr   = ParseExpr() }; }

        if (t.Type == TType.RAND) {
            Adv();
            return new RandNode { Min = ParseExpr(), Max = ParseExpr() };
        }

        // pack[...] — list literal
        if (t.Type == TType.PACK) {
            Adv();
            Expect(TType.LBRACKET, "Expected '['");
            var items = new List<Node>();
            while (!Check(TType.RBRACKET) && !Check(TType.EOF)) {
                items.Add(ParseExpr());
                Match(TType.COMMA);
            }
            Expect(TType.RBRACKET, "Expected ']'");
            return new PackNode { Items = items };
        }

        // Map literal: { "key": value, ... }
        if (t.Type == TType.LBRACE) {
            Adv();
            var pairs = new List<(Node, Node)>();
            while (!Check(TType.RBRACE) && !Check(TType.EOF)) {
                var key = ParseExpr();
                Expect(TType.COLON, "Expected ':' in map literal");
                var val = ParseExpr();
                pairs.Add((key, val));
                Match(TType.COMMA);
            }
            Expect(TType.RBRACE, "Expected '}'");
            return new MapNode { Pairs = pairs };
        }

        if (t.Type == TType.IDENT) {
            Adv();
            if (Check(TType.LPAREN))
                return new CallNode { Name=t.Raw, Args=ParseArgList() };
            return new IdentNode { Name = t.Raw };
        }

        Err($"Unexpected token '{t.Raw}'");
        return null!;
    }
}