enum TType {
    INT, FLOAT, STRING, IDENT,
    MAKE, SAY, ASK, CALC,
    LINK, GLOBAL,
    CHECK, BRANCH, OTHERWISE,
    CYCLE, SPIN, FOREACH, IN,
    CRAFT, GIVE,
    PACK, PUSHIN, PULLOUT,
    SIZEOF, KINDOF, RAND, PAUSE,
    STOP, SKIP,
    TRUE, FALSE,
    EQ, PLUSEQ, MINUSEQ, STAREQ, SLASHEQ,
    EQEQ, NEQ,
    LT, GT, LTE, GTE,
    PLUS, MINUS, STAR, SLASH, PERCENT,
    LPAREN, RPAREN,
    LBRACE, RBRACE,
    LBRACKET, RBRACKET,
    COMMA, DOT, COLON,
    AND, OR, NOT,
    EOF
}

class Token {
    public TType  Type;
    public string Raw;
    public long   IVal;
    public double FVal;
    public int    Line;

    public Token(TType t, string r, long i, double f, int l) {
        Type = t; Raw = r; IVal = i; FVal = f; Line = l;
    }

    public override string ToString() => $"[{Line}] {Type}({Raw})";
}