using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

enum VType { Null, Int, Float, Bool, String, List, Map }

class Value {
    public VType       Type;
    public long        IVal;
    public double      FVal;
    public string?     SVal;
    public List<Value>?              List;
    public Dictionary<string, Value>? Map;

    public static Value Null()         => new Value { Type=VType.Null };
    public static Value Int(long v)    => new Value { Type=VType.Int,    IVal=v, FVal=v };
    public static Value Float(double v)=> new Value { Type=VType.Float,  FVal=v, IVal=(long)v };
    public static Value Bool(bool v)   => new Value { Type=VType.Bool,   IVal=v?1:0 };
    public static Value Str(string? v) => new Value { Type=VType.String, SVal=v ?? "" };
    public static Value NewList()      => new Value { Type=VType.List,   List=new List<Value>() };
    public static Value NewMap()       => new Value { Type=VType.Map,    Map=new Dictionary<string, Value>() };

    public bool Truthy() => Type switch {
        VType.Null   => false,
        VType.Bool   => IVal != 0,
        VType.Int    => IVal != 0,
        VType.Float  => FVal != 0.0,
        VType.String => SVal != null && SVal.Length > 0,
        VType.List   => List != null && List.Count > 0,
        VType.Map    => Map  != null && Map.Count  > 0,
        _ => false
    };

    public string KindOf() => Type switch {
        VType.Null   => "null",
        VType.Int    => "int",
        VType.Float  => "float",
        VType.Bool   => "bool",
        VType.String => "string",
        VType.List   => "list",
        VType.Map    => "map",
        _ => "unknown"
    };

    public Value Copy() {
        if (Type == VType.List && List != null) {
            var nv = NewList();
            foreach (var item in List) nv.List!.Add(item.Copy());
            return nv;
        }
        if (Type == VType.Map && Map != null) {
            var nv = NewMap();
            foreach (var kv in Map) nv.Map![kv.Key] = kv.Value.Copy();
            return nv;
        }
        return new Value { Type=Type, IVal=IVal, FVal=FVal, SVal=SVal };
    }

    public override string ToString() => Type switch {
        VType.Null   => "null",
        VType.Bool   => IVal != 0 ? "true" : "false",
        VType.Int    => IVal.ToString(),
        VType.Float  => FVal.ToString("G"),
        VType.String => SVal ?? "",
        VType.List   => List != null ? "[" + string.Join(", ", List) + "]" : "[]",
        VType.Map    => Map  != null ? "{" + string.Join(", ", System.Linq.Enumerable.Select(Map, kv => $"\"{kv.Key}\": {kv.Value}")) + "}" : "{}",
        _ => "null"
    };
}

class ReturnException  : Exception { public Value Val; public ReturnException(Value v)  { Val = v; } }
class StopException    : Exception { public StopException()  : base("stop")  {} }
class SkipException    : Exception { public SkipException()  : base("skip")  {} }

class Env {
    readonly Dictionary<string, Value> _vars = new();
    readonly Env? _parent;

    public Env(Env? parent = null) { _parent = parent; }

    public void Define(string name, Value val) => _vars[name] = val;

    public void Set(string name, Value val) {
        if (_vars.ContainsKey(name)) { _vars[name] = val; return; }
        if (_parent != null && _parent.Has(name)) { _parent.Set(name, val); return; }
        _vars[name] = val;
    }

    public Value Get(string name) {
        if (_vars.TryGetValue(name, out var v)) return v;
        if (_parent != null) return _parent.Get(name);
        throw new Exception($"Variable '{name}' not defined");
    }

    public bool Has(string name) {
        if (_vars.ContainsKey(name)) return true;
        return _parent != null && _parent.Has(name);
    }
}


class Interpreter {
    readonly Env                           _global = new();
    readonly Dictionary<string, CraftStmt> _funcs  = new();
    readonly Random                        _rng    = new();
    readonly HashSet<string>               _linkedPlugins    = new();
    readonly HashSet<string>               _loadedStdModules = new();
    readonly Dictionary<string, string>    _stdFunctionMap   = new();

    public void Run(BlockNode block) {
        // Register the __tostr built-in used by string interpolation
        RegisterBuiltins();

        foreach (var stmt in block.Stmts) {
            if (stmt is LinkStmt link && link.Module != null)
                LoadPlugin(link.Module);
        }
        ExecBlock(block.Stmts, _global);
    }

    // ── Built-ins ────────────────────────────────────────────────────────────

    // We represent built-ins as CraftStmt with null Body; handled specially in CallFunc.
    readonly HashSet<string> _builtins = new();

    void RegisterBuiltins() {
        // __tostr(x) — used internally by string interpolation
        _builtins.Add("__tostr");
    }

    Value CallBuiltin(string name, List<Value> args) {
        switch (name) {
            case "__tostr":
                return Value.Str(args.Count > 0 ? args[0].ToString() : "");
            default:
                throw new Exception($"Unknown built-in '{name}'");
        }
    }

    // ── Module loading ───────────────────────────────────────────────────────

    void LoadPlugin(string moduleName) {
        if (_linkedPlugins.Contains(moduleName)) return;
        _linkedPlugins.Add(moduleName);

        string pluginPath = $"plugins/{moduleName}.gsl";
        if (File.Exists(pluginPath)) { LoadModuleFromFile(pluginPath); return; }

        string stdPath = $"std/{moduleName}.gsl";
        if (File.Exists(stdPath)) { LoadModuleFromFile(stdPath); return; }

        Console.WriteLine($"Warning: Plugin '{moduleName}' not found");
    }

    void LoadModuleFromFile(string path) {
        try {
            string src    = File.ReadAllText(path);
            var tokens    = new Lexer(src).TokenizeAll();
            var ast       = new Parser(tokens).Parse();
            string modName = Path.GetFileNameWithoutExtension(path);

            foreach (var stmt in ast.Stmts) {
                if (stmt is CraftStmt craft && craft.Name != null) {
                    _funcs[craft.Name] = craft;
                    if (path.StartsWith("std/"))
                        _stdFunctionMap[craft.Name] = modName;
                }
            }
            ExecBlock(ast.Stmts, _global);
        } catch (Exception ex) {
            throw new Exception($"Error loading module '{path}': {ex.Message}");
        }
    }

    bool TryLoadStdModuleForFunction(string funcName) {
        if (_stdFunctionMap.TryGetValue(funcName, out var moduleName)) {
            if (!_loadedStdModules.Contains(moduleName)) {
                _loadedStdModules.Add(moduleName);
                string stdPath = $"std/{moduleName}.gsl";
                if (File.Exists(stdPath)) { LoadModuleFromFile(stdPath); return true; }
            }
        }

        if (!Directory.Exists("std/")) return false;
        var allStdFiles = Directory.GetFiles("std/", "*.gsl");
        if (_loadedStdModules.Count < allStdFiles.Length) {
            foreach (var sf in allStdFiles) {
                string stdModuleName = Path.GetFileNameWithoutExtension(sf);
                if (_loadedStdModules.Contains(stdModuleName)) continue;
                try {
                    string src = File.ReadAllText(sf);
                    if (src.Contains($"craft {funcName}(") || src.Contains($"global craft {funcName}(")) {
                        _loadedStdModules.Add(stdModuleName);
                        LoadModuleFromFile(sf);
                        return true;
                    }
                } catch { }
            }
        }
        return false;
    }

    // ── Execution ────────────────────────────────────────────────────────────

    void ExecBlock(List<Node> stmts, Env env) {
        foreach (var stmt in stmts) Exec(stmt, env);
    }

    void Exec(Node node, Env env) {
        switch (node) {
            case LinkStmt:
                break; // handled in Run

            case MakeStmt m:
                env.Define(m.Name!, Eval(m.Value!, env));
                break;

            case AssignStmt a:
                env.Set(a.Name!, Eval(a.Value!, env));
                break;

            // Compound assignment: x += expr  etc.
            case CompoundAssignStmt ca: {
                var cur = env.Get(ca.Name!);
                var rhs = Eval(ca.Value!, env);
                Value result = ca.Op switch {
                    TType.PLUSEQ  => AddValues(cur, rhs),
                    TType.MINUSEQ => ArithValues(cur, rhs, TType.MINUS),
                    TType.STAREQ  => ArithValues(cur, rhs, TType.STAR),
                    TType.SLASHEQ => ArithValues(cur, rhs, TType.SLASH),
                    _ => throw new Exception($"Unknown compound op {ca.Op}")
                };
                env.Set(ca.Name!, result);
                break;
            }

            case IndexAssignStmt ia: {
                var container = env.Get(ia.Name!);
                var idx       = Eval(ia.Idx!, env);
                var val       = Eval(ia.Value!, env);

                if (container.Type == VType.List) {
                    int i = NormalizeIndex((int)idx.IVal, container.List!.Count);
                    container.List![i] = val.Copy();
                } else if (container.Type == VType.Map) {
                    container.Map![idx.ToString()] = val.Copy();
                } else {
                    throw new Exception($"'{ia.Name}' is not a list or map");
                }
                break;
            }

            case SayStmt s:
                Console.WriteLine(Eval(s.Expr!, env).ToString());
                break;

            case PauseStmt p: {
                var v    = Eval(p.Expr!, env);
                double s = v.Type == VType.Float ? v.FVal : v.IVal;
                Thread.Sleep((int)(s * 1000));
                break;
            }

            case PushinStmt pi: {
                var list = env.Get(pi.Name!);
                if (list.Type != VType.List) throw new Exception($"'{pi.Name}' is not a list");
                list.List!.Add(Eval(pi.Value!, env).Copy());
                break;
            }

            case PulloutStmt po: {
                var list = env.Get(po.Name!);
                var idx  = Eval(po.Idx!, env);
                if (list.Type != VType.List) throw new Exception($"'{po.Name}' is not a list");
                int i = NormalizeIndex((int)idx.IVal, list.List!.Count);
                list.List!.RemoveAt(i);
                break;
            }

            case GiveStmt g:
                throw new ReturnException(Eval(g.Expr!, env));

            case StopStmt:
                throw new StopException();

            case SkipStmt:
                throw new SkipException();

            case CallStmt cs: {
                var args = new List<Value>();
                foreach (var a in cs.Args!) args.Add(Eval(a, env));
                CallFunc(cs.Name!, args, env);
                break;
            }

            case CheckStmt ch: {
                bool hit = false;
                foreach (var (cond, body) in ch.Cases!) {
                    if (!hit && Eval(cond, env).Truthy()) {
                        ExecBlock(body, new Env(env));
                        hit = true;
                    }
                }
                if (!hit && ch.Otherwise != null)
                    ExecBlock(ch.Otherwise, new Env(env));
                break;
            }

            case CycleStmt cy: {
                var cv    = Eval(cy.Count!, env);
                long count = cv.Type == VType.Int ? cv.IVal : (long)cv.FVal;
                for (long i = 0; i < count; i++) {
                    try { ExecBlock(cy.Body!, new Env(env)); }
                    catch (StopException) { break; }
                    catch (SkipException) { continue; }
                }
                break;
            }

            case SpinStmt sp:
                while (Eval(sp.Cond!, env).Truthy()) {
                    try { ExecBlock(sp.Body!, new Env(env)); }
                    catch (StopException) { break; }
                    catch (SkipException) { continue; }
                }
                break;

            // foreach item in list { ... }
            case ForeachStmt fe: {
                var listVal = Eval(fe.List!, env);
                if (listVal.Type == VType.List) {
                    foreach (var item in listVal.List!) {
                        var loopEnv = new Env(env);
                        loopEnv.Define(fe.Var!, item.Copy());
                        try { ExecBlock(fe.Body!, loopEnv); }
                        catch (StopException) { break; }
                        catch (SkipException) { continue; }
                    }
                } else if (listVal.Type == VType.Map) {
                    foreach (var kv in listVal.Map!) {
                        var loopEnv = new Env(env);
                        // Expose as a two-item list [key, value]
                        var pair = Value.NewList();
                        pair.List!.Add(Value.Str(kv.Key));
                        pair.List!.Add(kv.Value.Copy());
                        loopEnv.Define(fe.Var!, pair);
                        try { ExecBlock(fe.Body!, loopEnv); }
                        catch (StopException) { break; }
                        catch (SkipException) { continue; }
                    }
                } else if (listVal.Type == VType.String) {
                    foreach (char ch in listVal.SVal!) {
                        var loopEnv = new Env(env);
                        loopEnv.Define(fe.Var!, Value.Str(ch.ToString()));
                        try { ExecBlock(fe.Body!, loopEnv); }
                        catch (StopException) { break; }
                        catch (SkipException) { continue; }
                    }
                } else {
                    throw new Exception("foreach requires a list, map, or string");
                }
                break;
            }

            case CraftStmt cr:
                _funcs[cr.Name!] = cr;
                break;

            default:
                Eval(node, env);
                break;
        }
    }

    // ── Evaluation ───────────────────────────────────────────────────────────

    Value Eval(Node node, Env env) {
        switch (node) {
            case NumberNode n:
                return n.Tok!.Type == TType.FLOAT
                    ? Value.Float(n.Tok.FVal)
                    : Value.Int(n.Tok.IVal);

            case StringNode s:
                return Value.Str(s.Tok!.Raw);

            case BoolNode b:
                return Value.Bool(b.Val);

            case IdentNode id:
                return env.Get(id.Name!).Copy();

            case PackNode pk: {
                var list = Value.NewList();
                foreach (var item in pk.Items!) list.List!.Add(Eval(item, env).Copy());
                return list;
            }

            // Map literal { "key": val, ... }
            case MapNode mn: {
                var map = Value.NewMap();
                foreach (var (k, v) in mn.Pairs!) {
                    var key = Eval(k, env).ToString();
                    map.Map![key] = Eval(v, env).Copy();
                }
                return map;
            }

            case IndexNode ix: {
                var obj = Eval(ix.Obj!, env);
                var idx = Eval(ix.Idx!, env);

                if (obj.Type == VType.List) {
                    int i = NormalizeIndex((int)idx.IVal, obj.List!.Count);
                    return obj.List![i].Copy();
                }
                if (obj.Type == VType.String) {
                    int i = NormalizeIndex((int)idx.IVal, obj.SVal!.Length);
                    return Value.Str(obj.SVal![i].ToString());
                }
                if (obj.Type == VType.Map) {
                    string key = idx.ToString();
                    if (!obj.Map!.TryGetValue(key, out var mv))
                        throw new Exception($"Map key '{key}' not found");
                    return mv.Copy();
                }
                throw new Exception("Cannot index non-list/string/map");
            }

            case AskNode ask: {
                var prompt = Eval(ask.Prompt!, env);
                Console.Write(prompt.ToString() + " ");
                string inp = Console.ReadLine() ?? "";
                if (long.TryParse(inp, out long iv))     return Value.Int(iv);
                if (double.TryParse(inp, out double fv)) return Value.Float(fv);
                return Value.Str(inp);
            }

            case CalcNode calc:
                return Eval(calc.Expr!, env);

            case SizeofNode sz: {
                var v = Eval(sz.Expr!, env);
                if (v.Type == VType.List)   return Value.Int(v.List!.Count);
                if (v.Type == VType.String) return Value.Int(v.SVal!.Length);
                if (v.Type == VType.Map)    return Value.Int(v.Map!.Count);
                throw new Exception("sizeof requires list, map, or string");
            }

            case KindofNode kd:
                return Value.Str(Eval(kd.Expr!, env).KindOf());

            case RandNode rnd: {
                var mn = Eval(rnd.Min!, env);
                var mx = Eval(rnd.Max!, env);
                long lo = mn.Type == VType.Int ? mn.IVal : (long)mn.FVal;
                long hi = mx.Type == VType.Int ? mx.IVal : (long)mx.FVal;
                return Value.Int(_rng.NextInt64(lo, hi + 1));
            }

            case CallNode cn: {
                var args = new List<Value>();
                foreach (var a in cn.Args!) args.Add(Eval(a, env));
                return CallFunc(cn.Name!, args, env);
            }

            case BinOpNode b:
                return EvalBinOp(b, env);

            case UnOpNode u: {
                var v = Eval(u.Operand!, env);
                if (u.Op == TType.MINUS)
                    return v.Type == VType.Float ? Value.Float(-v.FVal) : Value.Int(-v.IVal);
                if (u.Op == TType.NOT)
                    return Value.Bool(!v.Truthy());
                throw new Exception($"Unknown unary op {u.Op}");
            }

            default:
                Exec(node, env);
                return Value.Null();
        }
    }

    Value EvalBinOp(BinOpNode b, Env env) {
        if (b.Op == TType.AND) {
            var l = Eval(b.Left!, env);
            return l.Truthy() ? Eval(b.Right!, env) : l;
        }
        if (b.Op == TType.OR) {
            var l = Eval(b.Left!, env);
            return l.Truthy() ? l : Eval(b.Right!, env);
        }

        var left  = Eval(b.Left!,  env);
        var right = Eval(b.Right!, env);

        switch (b.Op) {
            case TType.PLUS:    return AddValues(left, right);
            case TType.MINUS:   return ArithValues(left, right, TType.MINUS);
            case TType.STAR:    return ArithValues(left, right, TType.STAR);
            case TType.SLASH:   return ArithValues(left, right, TType.SLASH);
            case TType.PERCENT:
                if (right.IVal == 0) throw new Exception("Modulo by zero");
                return Value.Int(left.IVal % right.IVal);

            case TType.EQEQ: return Value.Bool(ValEq(left, right));
            case TType.NEQ:  return Value.Bool(!ValEq(left, right));
            case TType.LT:   return Value.Bool(ValCmp(left, right) < 0);
            case TType.GT:   return Value.Bool(ValCmp(left, right) > 0);
            case TType.LTE:  return Value.Bool(ValCmp(left, right) <= 0);
            case TType.GTE:  return Value.Bool(ValCmp(left, right) >= 0);

            default:
                throw new Exception($"Unknown operator {b.Op}");
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    // Negative index support: -1 => last element
    static int NormalizeIndex(int i, int len) {
        if (i < 0) i = len + i;
        if (i < 0 || i >= len) throw new Exception("Index out of range");
        return i;
    }

    Value AddValues(Value left, Value right) {
        if (left.Type == VType.String || right.Type == VType.String)
            return Value.Str(left.ToString() + right.ToString());
        if (left.Type == VType.Float || right.Type == VType.Float)
            return Value.Float(left.FVal + right.FVal);
        return Value.Int(left.IVal + right.IVal);
    }

    Value ArithValues(Value left, Value right, TType op) {
        switch (op) {
            case TType.MINUS:
                if (left.Type == VType.Float || right.Type == VType.Float)
                    return Value.Float(left.FVal - right.FVal);
                return Value.Int(left.IVal - right.IVal);
            case TType.STAR:
                if (left.Type == VType.Float || right.Type == VType.Float)
                    return Value.Float(left.FVal * right.FVal);
                return Value.Int(left.IVal * right.IVal);
            case TType.SLASH:
                if (right.FVal == 0 && right.IVal == 0) throw new Exception("Division by zero");
                return Value.Float(left.FVal / right.FVal);
            default:
                throw new Exception($"Unknown arith op {op}");
        }
    }

    Value CallFunc(string name, List<Value> args, Env callEnv) {
        // Built-ins first
        if (_builtins.Contains(name))
            return CallBuiltin(name, args);

        // Lazy load from std modules
        if (!_funcs.ContainsKey(name))
            TryLoadStdModuleForFunction(name);

        if (!_funcs.TryGetValue(name, out var fn))
            throw new Exception($"Function '{name}' not defined");

        var scope = new Env(_global);
        for (int i = 0; i < fn.Params!.Count && i < args.Count; i++)
            scope.Define(fn.Params[i], args[i].Copy());

        try {
            ExecBlock(fn.Body!, scope);
        } catch (ReturnException r) {
            return r.Val;
        }

        return Value.Null();
    }

    bool ValEq(Value a, Value b) {
        if (a.Type == VType.Null && b.Type == VType.Null) return true;
        if (a.Type == VType.String && b.Type == VType.String) return a.SVal == b.SVal;
        if (a.Type == VType.Bool   && b.Type == VType.Bool)   return a.IVal == b.IVal;
        return ValNum(a) == ValNum(b);
    }

    double ValNum(Value v) => v.Type == VType.Float ? v.FVal : v.IVal;

    double ValCmp(Value a, Value b) {
        if (a.Type == VType.String && b.Type == VType.String)
            return string.Compare(a.SVal, b.SVal, StringComparison.Ordinal);
        return ValNum(a) - ValNum(b);
    }
}